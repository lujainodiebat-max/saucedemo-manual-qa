Package notes

Evidence screenshots are in evidence/.

Corrections made:
- Product-image behavior with problem_user is documented as known seeded demo behavior, not a confirmed unexpected defect.
- Login performance with performance_glitch_user is NOT VERIFIED because no measured duration was supplied.
- The old bug list is now an observations register; there are no confirmed unexpected defects supported by the current evidence.
- Test Plan document-control version/date now match the cover page.
- Test Plan exit criteria no longer imply that retesting/regression were completed without supporting records.
- TEST-SUMMARY.md records the current results and limitations.

Before publishing, re-run the timing test and record OS, browser/version, date, and actual elapsed time. Keep the existing screenshot evidence; do not invent execution details.
